const express = require('express');
const router = express.Router();

const auth = require('../middleware/auth');
const multer = require('../middleware/multer-config');
const sauceControl = require('../controllers/Sauce');

router.get('/', auth, sauceControl.getAllSauces);
router.get('/:id', auth, sauceControl.getSauce);
router.post('/', auth, multer, sauceControl.createSauce);
router.put('/:id', auth, multer, sauceControl.modifySauce);
router.delete('/:id', auth, multer, sauceControl.deleteSauce);

module.exports = router;